package com.example.SashankaDemo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SashankaDemoApplicationTests {

	@Test
	void contextLoads() {
	}

}
